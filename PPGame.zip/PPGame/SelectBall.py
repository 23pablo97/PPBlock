import pygame
from Pelota import *
import math
import sys
from centered_figure import *

def selectBall(pantalla):
    pelotas = [Pelota([(-50,50),(50,50),(50,-50),(-50,-50)],[193,330],(255,255,255),pantalla),
               Pelota([(50*cos(22.5*pi/180),50*sin(22.5*pi/180)),(50*cos(67.5*pi/180),50*sin(67.5*pi/180)),(-50*cos(67.5*pi/180),50*sin(67.5*pi/180)),(-50*cos(22.5*pi/180),50*sin(22.5*pi/180)),(-50*cos(22.5*pi/180),-50*sin(22.5*pi/180)),(-50*cos(67.5*pi/180),-50*sin(67.5*pi/180)),(50*cos(67.5*pi/180),-50*sin(67.5*pi/180)),(50*cos(22.5*pi/180),-50*sin(22.5*pi/180))],[193,330],(255,255,255),pantalla),
               Pelota([(-50*cos(18*pi/180),-50*sin(18*pi/180)),(-50*cos(90*pi/180),-50*sin(90*pi/180)),(-50*cos(162*pi/180),-50*sin(162*pi/180)),(-50*cos(234*pi/180),-50*sin(234*pi/180)),(-50*cos(306*pi/180),-50*sin(306*pi/180))],[193,330],(255,255,255),pantalla),
               Pelota([(-50*cos(234*pi/180),-50*sin(234*pi/180)), (-50*cos(90*pi/180),-50*sin(90*pi/180)), (-50*cos(306*pi/180),-50*sin(306*pi/180)), (-50*cos(162*pi/180),-50*sin(162*pi/180)), (-50*cos(18*pi/180),-50*sin(18*pi/180))], [193, 330], (255, 255, 255), pantalla)]
    estado = 0

    while True:
        pelotas[estado].draw()

        der = CenteredFigure([(-10*cos(0),-10*sin(0)),(-10*cos(120*pi/180),-10*sin(120*pi/180)),(-10*cos(240*pi/180),-10*sin(240*pi/180))],[64,330],(255,255,255),0,pantalla)
        izq = CenteredFigure([(10 * cos(0), 10 * sin(0)), (10 * cos(120 * pi / 180), 10 * sin(120 * pi / 180)),
                              (10 * cos(240 * pi / 180), 10 * sin(240 * pi / 180))], [320, 330], (255, 255, 255), 0,
                             pantalla)
        der.draw()
        izq.draw()

        fuente = pygame.font.Font("font/Pixeled.ttf", 20)
        title = fuente.render("UP to SELECT", True, BLANCO)
        pantalla.blit(title, (90,500))
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    if estado == 0:
                        return [(-6,6),(6,6),(6,-6),(-6,-6)]
                    elif estado == 1:
                        return [(6*cos(22.5*pi/180),6*sin(22.5*pi/180)),(6*cos(67.5*pi/180),6*sin(67.5*pi/180)),(-6*cos(67.5*pi/180),6*sin(67.5*pi/180)),(-6*cos(22.5*pi/180),6*sin(22.5*pi/180)),(-6*cos(22.5*pi/180),-6*sin(22.5*pi/180)),(-6*cos(67.5*pi/180),-6*sin(67.5*pi/180)),(6*cos(67.5*pi/180),-6*sin(67.5*pi/180)),(6*cos(22.5*pi/180),-6*sin(22.5*pi/180))]
                    elif estado == 2:
                        return [(-6*cos(18*pi/180),-6*sin(18*pi/180)),(-6*cos(90*pi/180),-6*sin(90*pi/180)),(-6*cos(162*pi/180),-6*sin(162*pi/180)),(-6*cos(234*pi/180),-6*sin(234*pi/180)),(-6*cos(306*pi/180),-6*sin(306*pi/180))]
                    else:
                        return [(-6*cos(234*pi/180),-6*sin(234*pi/180)), (-6*cos(90*pi/180),-6*sin(90*pi/180)), (-6*cos(306*pi/180),-6*sin(306*pi/180)), (-6*cos(162*pi/180),-6*sin(162*pi/180)), (-6*cos(18*pi/180),-6*sin(18*pi/180))]

                elif event.key == pygame.K_LEFT:
                    pelotas[estado].borrar()
                    if estado != 0: estado-=1
                    else: estado = 3
                elif event.key == pygame.K_RIGHT:
                    pelotas[estado].borrar()
                    if estado != 3: estado+=1
                    else: estado = 0