from contorno import *

class bloque:
    def __init__(self, x, y, lado, color, fondo, nombre, vidas, pantalla):
        self.x = x
        self.y = y
        self.vidas = vidas
        self.nombre = nombre
        self.fondo = fondo
        self.color = color
        self.lado = lado
        self.pantalla = pantalla
        self.up = Contorno(x,y,lado,3,"up",pantalla,color,fondo)
        self.left = Contorno(x,y,3,lado,"left",pantalla,color,fondo)
        self.right = Contorno(x+lado,y,-3,lado,"right",pantalla,color,fondo)
        self.down = Contorno(x,y+lado,lado,-3,"down",pantalla,color,fondo)
        self.figura = [self.down, self.up, self.left, self.right]


    def draw(self):
        self.up.draw()
        self.down.draw()
        self.left.draw()
        self.right.draw()
        posX = self.x + 7
        posY = self.y + 7
        fuente = pygame.font.Font(None, 26)
        mensaje = fuente.render(str(self.vidas), True, self.color)
        self.pantalla.blit(mensaje, (posX, posY))

    def borrar(self):
        self.up.borrar()
        self.down.borrar()
        self.left.borrar()
        self.right.borrar()
        posX = self.x + 7
        posY = self.y + 7
        fuente = pygame.font.Font(None, 26)
        mensaje = fuente.render(str(self.vidas), True, self.fondo)
        self.pantalla.blit(mensaje, (posX, posY))