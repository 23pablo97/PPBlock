import math
from Fila import *
import pygame
import time

NEGRO = (0,0,0)
BLANCO = (255,255,255)

def disenoMenu(pantalla,estado):
    fuente = pygame.font.Font("font/Pixeled.ttf", 40)
    title = fuente.render("PP-GAME", True, BLANCO)
    pantalla.blit(title, (60, 60))

    fuente = pygame.font.Font("font/Pixeled.ttf", 20)
    start = fuente.render("Start", True, BLANCO)
    choose = fuente.render("Choose ball", True, BLANCO)
    exit = fuente.render("Exit", True, BLANCO)

    fuente = pygame.font.Font("font/Pixeled.ttf", 10)
    instruccion = fuente.render("SPACE to SELECT", True, BLANCO)
    pantalla.blit(instruccion, (18, 350))

    fuente = pygame.font.Font("font/Pixeled.ttf", 15)
    selector = fuente.render("o", True, BLANCO)
    pantalla.blit(selector, (18, 395 + 32 * estado))

    pantalla.blit(start, (45, 390))
    pantalla.blit(choose, (45, 420))

    pantalla.blit(exit, (45, 452))

def angulo(x1,y1,x2,y2):
    return 180-math.atan2(y1-y2,x1-x2)*180/math.pi


def MF(nivel,filas,pantalla):
    fuente = pygame.font.Font(None, 28)
    mensaje = fuente.render(str(nivel-1), True, NEGRO)
    pantalla.blit(mensaje, (193, 20))
    mensaje = fuente.render(str(nivel), True, BLANCO)
    pantalla.blit(mensaje, (193, 20))
    filas = moverFilas(filas, pantalla, nivel)
    filas[0].pintarFila()
    if filas[7] != 0 and len(cuadros_filas([filas[7]])) != 0:
        return True
    if filas[7] != 0: filas[7].borrarFila()
    return False

def moverImagen(imagen,negro,posI,posF):
    if posF - posI < 0:
        while posI <= posF:
            pantalla.blit(negro, (posI + 1, 494 + 53))
            pantalla.blit(imagen,(posI+1,494+53))
            posI += 1
            pygame.display.update()
            time.sleep(0.0001)
    else:
        while posI >= posF:
            pantalla.blit(negro, (posI - 1, 494 + 53))
            pantalla.blit(imagen,(posI-1,494+53))
            posI -= 1
            pygame.display.update()
            time.sleep(0.0001)