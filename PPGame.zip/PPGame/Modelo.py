import pygame, sys
import math
from centered_figure import *
from Pelota import *
from contorno import *
from Bloques import *
from Fila import *
from Otros import *
from BloqueTriangulo import *

# COLORES
BLANCO = (255, 255, 255)
NEGRO = (0, 0, 0)
MAGENTA = (255, 0, 255)
ROJO = (255, 117, 020)

def modelo(menu, vertices, pantalla):
    # CONTORNO

    Contorno1 = Contorno(-2, 54, 1, 496, "left", pantalla, BLANCO, NEGRO)
    Contorno2 = Contorno(-1, 54, 387, 1, "up", pantalla, BLANCO, NEGRO)
    Contorno3 = Contorno(386, 54, -1, 496, "right", pantalla, BLANCO, NEGRO)
    Contorno4 = Contorno(-1, 496 + 55, 387, -1, "down", pantalla, BLANCO, NEGRO)

    #OBJETOS
    contorno = [Contorno1, Contorno2, Contorno3]

    # NOMBRE INFERIOR
    a1 = CenteredFigure([(0, 0), (50, 0), (50, 65), (0, 65)], [2, 605], (255, 128, 0), 0, pantalla)
    a2 = CenteredFigure([(0, 0), (50, 0), (50, 65), (0, 65)], [2 + 55, 610], (255, 191, 0), 0, pantalla)
    a3 = CenteredFigure([(0, 0), (50, 0), (50, 65), (0, 65)], [2 + 2 * 55, 607], (172, 105, 83), 0, pantalla)
    a4 = CenteredFigure([(0, 0), (50, 0), (50, 65), (0, 65)], [2 + 3 * 55, 605], (128, 128, 128), 0, pantalla)
    a5 = CenteredFigure([(0, 0), (50, 0), (50, 65), (0, 65)], [2 + 4 * 55, 612], (0, 64, 255), 0, pantalla)
    a6 = CenteredFigure([(0, 0), (50, 0), (50, 65), (0, 65)], [2 + 5 * 55, 606], (255, 0, 191), 0, pantalla)
    a7 = CenteredFigure([(0, 0), (50, 0), (50, 65), (0, 65)], [2 + 6 * 55, 605], (255, 0, 64), 0, pantalla)
    a1.draw()
    fuente = pygame.font.Font(None, 30)
    mensaje = fuente.render("P", True, BLANCO)
    pantalla.blit(mensaje, (22, 626))
    a2.draw()
    fuente = pygame.font.Font(None, 30)
    mensaje = fuente.render("P", True, BLANCO)
    pantalla.blit(mensaje, (22 + 55, 626))
    a3.draw()
    a4.draw()
    fuente = pygame.font.Font(None, 30)
    mensaje = fuente.render("G", True, BLANCO)
    pantalla.blit(mensaje, (22 + 3 * 55, 626))
    a5.draw()
    fuente = pygame.font.Font(None, 30)
    mensaje = fuente.render("A", True, BLANCO)
    pantalla.blit(mensaje, (22 + 4 * 55, 626))
    a6.draw()
    fuente = pygame.font.Font(None, 30)
    mensaje = fuente.render("M", True, BLANCO)
    pantalla.blit(mensaje, (22 + 5 * 55, 626))
    a7.draw()
    fuente = pygame.font.Font(None, 30)
    mensaje = fuente.render("E", True, BLANCO)
    pantalla.blit(mensaje, (22 + 6 * 55, 626))

    fuente = pygame.font.Font(None, 20)
    mensaje = fuente.render("ESC to exit", True, BLANCO)
    pantalla.blit(mensaje, (15, 22))

    bolas = [Pelota(vertices,[193, 494 + 55], BLANCO, pantalla)]
    bolas[0].draw()

    posIMAGEN = 173
    negro = pygame.image.load("images/negro.jpg")
    negro = pygame.transform.scale(negro, (100, 50))
    pantalla.blit(negro, (posIMAGEN, 494 + 53 + 2))
    personaje = pygame.image.load("images/lanzador.png")
    personaje = pygame.transform.scale(personaje, (50, 50))
    pantalla.blit(personaje, (posIMAGEN, 494 + 53))

    filas = [0, 0, 0, 0, 0, 0, 0, 0]
    nivel = 1
    filas = moverFilas(filas, pantalla, nivel)
    filas[0].pintarFila()
    Contorno1.draw()
    Contorno2.draw()
    Contorno3.draw()
    Contorno4.draw()

    cuadros = cuadros_filas(filas)
    powersUp = power_filas(filas)

    fuente = pygame.font.Font(None, 26)
    mensaje = fuente.render(str(nivel), True, BLANCO)
    pantalla.blit(mensaje, (193, 20))

    posFlecha = [int(bolas[0].centro[0]),490+55]

    ang = 0
    while not menu:

        if abs(ang * 180 / pi) <= 80:
            flecha = CenteredFigure([(-2 * cos(ang), -2 * sin(ang)),
                                     (-50.04 * cos(ang + 87.71 * pi / 180), -50.04 * sin(ang + 87.71 * pi / 180)),
                                     (-50.49 * cos(ang + 82.03 * pi / 180), -50.49 * sin(ang + 82.03 * pi / 180)),
                                     (-70 * cos(ang + pi / 2), -70 * sin(ang + pi / 2)),
                                     (-50.49 * cos(ang + 97.96 * pi / 180), -50.49 * sin(ang + 97.96 * pi / 180)),
                                     (-50.04 * cos(ang + 92.29 * pi / 180), -50.04 * sin(ang + 92.29 * pi / 180)),
                                     (-2 * cos(ang + pi), -2 * sin(ang + pi))], posFlecha, (0, 0, 0), 0, pantalla)
            flecha.draw()

        pos = pygame.mouse.get_pos()
        ang = angulo(pos[0], pos[1], flecha._center[0], flecha._center[1])

        ang = (-ang + 180+90) * pi / 180


        if abs(ang * 180 / pi) <= 80:
            flecha = CenteredFigure([(-2 * cos(ang), -2 * sin(ang)),
                                     (-50.04 * cos(ang + 87.71 * pi / 180), -50.04 * sin(ang + 87.71 * pi / 180)),
                                     (-50.49 * cos(ang + 82.03 * pi / 180), -50.49 * sin(ang + 82.03 * pi / 180)),
                                     (-70 * cos(ang + pi / 2), -70 * sin(ang + pi / 2)),
                                     (-50.49 * cos(ang + 97.96 * pi / 180), -50.49 * sin(ang + 97.96 * pi / 180)),
                                     (-50.04 * cos(ang + 92.29 * pi / 180), -50.04 * sin(ang + 92.29 * pi / 180)),
                                     (-2 * cos(ang + pi), -2 * sin(ang + pi))], posFlecha, (255, 255, 255), 0, pantalla)

            flecha.draw()

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                sys.exit()

            if event.type == pygame.MOUSEBUTTONUP:

                flecha = CenteredFigure([(-2 * cos(ang), -2 * sin(ang)),
                                         (-50.04 * cos(ang + 87.71 * pi / 180), -50.04 * sin(ang + 87.71 * pi / 180)),
                                         (-50.49 * cos(ang + 82.03 * pi / 180), -50.49 * sin(ang + 82.03 * pi / 180)),
                                         (-70 * cos(ang + pi / 2), -70 * sin(ang + pi / 2)),
                                         (-50.49 * cos(ang + 97.96 * pi / 180), -50.49 * sin(ang + 97.96 * pi / 180)),
                                         (-50.04 * cos(ang + 92.29 * pi / 180), -50.04 * sin(ang + 92.29 * pi / 180)),
                                         (-2 * cos(ang + pi), -2 * sin(ang + pi))], posFlecha, (0, 0, 0), 0, pantalla)
                flecha.draw()
                pos = pygame.mouse.get_pos()
                ang = angulo(bolas[0].centro[0], bolas[0].centro[1], pos[0], pos[1])
                filas = actualizar(filas)

                if ang >= 170 and ang <= 270:
                    ang=170
                elif ang > 270 and ang<= 370:
                    ang = 10

                mas = moverHasta(bolas, -ang, contorno, filas, powersUp, 495 + 55)

                while mas[0] > 0:
                    bolas += [Pelota(bolas[0].vertices,[mas[1], 494 + 55], BLANCO, pantalla)]
                    mas[0] -= 1

                if len(mas[2]) != 0:
                    for fila in filas:
                        if fila != 0:
                            for cuadro in mas[2]:
                                for i in range(len(fila.lista)):
                                    if fila.lista[i] == cuadro:
                                        fila.lista[i] = 0

                cuadros = cuadros_filas(filas)
                contorno = [Contorno1, Contorno2, Contorno3]
                powersUp = power_filas(filas)

                Contorno1.draw()
                Contorno2.draw()
                Contorno3.draw()
                Contorno4.draw()

                posF = bolas[0].centro[0]
                if posF - posIMAGEN < 0:
                    while posIMAGEN >= posF - 20:
                        pantalla.blit(negro, (posIMAGEN - 1, 494 + 53 + 5))
                        pantalla.blit(personaje, (posIMAGEN - 1, 494 + 53))
                        posIMAGEN -= 4
                        pygame.display.update()
                        time.sleep(0.0001)
                else:
                    while posIMAGEN <= posF - 20:
                        pantalla.blit(negro, (posIMAGEN - 3, 494 + 53 + 5))
                        pantalla.blit(personaje, (posIMAGEN + 1, 494 + 53))
                        posIMAGEN += 4
                        pygame.display.update()
                        time.sleep(0.0001)

                nivel += 1
                if MF(nivel, filas, pantalla):
                    menu = True

                posFlecha = [int(posF), 490+55]

            # Movimiento
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    menu = True

        pygame.display.update()






