from contorno import *
import math

class DiagonalA:

    def __init__(self, x,y, ancho,grosor,posicion,pantalla,color,fondo):
        self.x = x
        self.y = y
        self.ancho = ancho
        self.grosor = grosor
        self.posicion = posicion
        self.color=color
        self.fondo=fondo
        self.pantalla = pantalla
        self.figura = CenteredFigure([(0,0),(0,math.sqrt(2)*math.pow(self.grosor,2)),(self.ancho - math.sqrt(2)*math.pow(self.grosor,2),self.ancho),(self.ancho,self.ancho)],
                                     [self.x, self.y], self.color, 0, self.pantalla)


    def draw(self):
        self.figura = CenteredFigure([(0,0),(0,math.sqrt(2)*math.pow(self.grosor,2)),(self.ancho - math.sqrt(2)*math.pow(self.grosor,2),self.ancho),(self.ancho,self.ancho)],
                                     [self.x, self.y], self.color, 0, self.pantalla)
        self.figura.draw()

    def borrar(self):
        self.figura = CenteredFigure([(0,0),(0,math.sqrt(2)*math.pow(self.grosor,2)),(self.ancho - math.sqrt(2)*math.pow(self.grosor,2),self.ancho),(self.ancho,self.ancho)],
                                     [self.x, self.y], self.fondo, 0, self.pantalla)
        self.figura.draw()

class DiagonalB:

    def __init__(self, x,y, ancho,grosor,posicion,pantalla,color,fondo):
        self.x = x
        self.y = y
        self.ancho = ancho
        self.grosor = grosor
        self.posicion = posicion
        self.color=color
        self.fondo=fondo
        self.pantalla = pantalla
        self.figura = CenteredFigure([(0,0),(math.sqrt(2)*math.pow(self.grosor,2),0),(self.ancho,self.ancho - math.sqrt(2)*math.pow(self.grosor,2)),(self.ancho,self.ancho)],
                                     [self.x, self.y], self.color, 0, self.pantalla)


    def draw(self):
        self.figura = CenteredFigure([(0,0),(math.sqrt(2)*math.pow(self.grosor,2),0),(self.ancho,self.ancho - math.sqrt(2)*math.pow(self.grosor,2)),(self.ancho,self.ancho)],
                                     [self.x, self.y], self.color, 0, self.pantalla)
        self.figura.draw()

    def borrar(self):
        self.figura = CenteredFigure([(0,0),(math.sqrt(2)*math.pow(self.grosor,2),0),(self.ancho,self.ancho - math.sqrt(2)*math.pow(self.grosor,2)),(self.ancho,self.ancho)],
                                     [self.x, self.y], self.fondo, 0, self.pantalla)
        self.figura.draw()

class DiagonalC:

    def __init__(self, x,y, ancho,grosor,posicion,pantalla,color,fondo):
        self.x = x
        self.y = y
        self.ancho = ancho
        self.grosor = grosor
        self.posicion = posicion
        self.color=color
        self.fondo=fondo
        self.pantalla = pantalla
        self.figura = CenteredFigure([(0,0),(-math.sqrt(2)*math.pow(self.grosor,2),0),(-self.ancho,self.ancho - math.sqrt(2)*math.pow(self.grosor,2)),(-self.ancho,self.ancho)],
                                     [self.x, self.y], self.color, 0, self.pantalla)


    def draw(self):
        self.figura = CenteredFigure([(0,0),(-math.sqrt(2)*math.pow(self.grosor,2),0),(-self.ancho,self.ancho - math.sqrt(2)*math.pow(self.grosor,2)),(-self.ancho,self.ancho)],
                                     [self.x, self.y], self.color, 0, self.pantalla)
        self.figura.draw()

    def borrar(self):
        self.figura = CenteredFigure([(0,0),(-math.sqrt(2)*math.pow(self.grosor,2),0),(-self.ancho,self.ancho - math.sqrt(2)*math.pow(self.grosor,2)),(-self.ancho,self.ancho)],
                                     [self.x, self.y], self.fondo, 0, self.pantalla)
        self.figura.draw()

class DiagonalD:

    def __init__(self, x,y, ancho,grosor,posicion,pantalla,color,fondo):
        self.x = x
        self.y = y
        self.ancho = ancho
        self.grosor = grosor
        self.posicion = posicion
        self.color=color
        self.fondo=fondo
        self.pantalla = pantalla
        self.figura = CenteredFigure([(0,0),(0,math.sqrt(2)*math.pow(self.grosor,2)),(-self.ancho + math.sqrt(2)*math.pow(self.grosor,2),self.ancho),(-self.ancho,self.ancho)],
                                     [self.x, self.y], self.color, 0, self.pantalla)


    def draw(self):
        self.figura = CenteredFigure([(0,0),(0,math.sqrt(2)*math.pow(self.grosor,2)),(-self.ancho + math.sqrt(2)*math.pow(self.grosor,2),self.ancho),(-self.ancho,self.ancho)],
                                     [self.x, self.y], self.color, 0, self.pantalla)
        self.figura.draw()

    def borrar(self):
        self.figura = CenteredFigure([(0,0),(0,math.sqrt(2)*math.pow(self.grosor,2)),(-self.ancho + math.sqrt(2)*math.pow(self.grosor,2),self.ancho),(-self.ancho,self.ancho)],
                                     [self.x, self.y], self.fondo, 0, self.pantalla)
        self.figura.draw()

class trianguloA:
    def __init__(self, x, y, lado, color, fondo, nombre, vidas, pantalla):
        self.x = x
        self.y = y
        self.vidas = vidas
        self.nombre = nombre
        self.fondo = fondo
        self.color = color
        self.lado = lado
        self.pantalla = pantalla
        self.left = Contorno(self.x,self.y,3,lado,"left",pantalla,color,fondo)
        self.down = Contorno(self.x,self.y + lado, lado, -3, "down", pantalla, color, fondo)
        self.hip = DiagonalA(self.x,self.y,self.lado,1.9,"hipA",pantalla,color,fondo)
        self.figura = [self.down, self.left, self.hip]

    def draw(self):
        self.down.draw()
        self.left.draw()
        self.hip.draw()
        posX = self.x + 7
        posY = self.y + self.lado - 20
        fuente = pygame.font.Font(None, 26)
        mensaje = fuente.render(str(self.vidas), True, self.color)
        self.pantalla.blit(mensaje, (posX, posY))

    def borrar(self):
        self.down.borrar()
        self.left.borrar()
        self.hip.borrar()
        posX = self.x + 7
        posY = self.y + self.lado - 20
        fuente = pygame.font.Font(None, 26)
        mensaje = fuente.render(str(self.vidas), True, self.fondo)
        self.pantalla.blit(mensaje, (posX, posY))

class trianguloB:
    def __init__(self, x, y, lado, color, fondo, nombre, vidas, pantalla):
        self.x = x
        self.y = y
        self.vidas = vidas
        self.nombre = nombre
        self.fondo = fondo
        self.color = color
        self.lado = lado
        self.pantalla = pantalla
        self.right = Contorno(self.x+lado,self.y,-3,lado,"right",pantalla,color,fondo)
        self.up = Contorno(self.x, self.y, lado, 3, "up", pantalla, color, fondo)
        self.hip = DiagonalB(self.x,self.y,self.lado,1.9,"hipB",pantalla,color,fondo)
        self.figura = [self.right, self.up, self.hip]

    def draw(self):
        self.right.draw()
        self.up.draw()
        self.hip.draw()
        posX = self.x + self.lado - 20
        posY = self.y + 7
        fuente = pygame.font.Font(None, 26)
        mensaje = fuente.render(str(self.vidas), True, self.color)
        self.pantalla.blit(mensaje, (posX, posY))

    def borrar(self):
        self.right.borrar()
        self.up.borrar()
        self.hip.borrar()
        posX = self.x + 23
        posY = self.y + 20
        fuente = pygame.font.Font(None, 26)
        mensaje = fuente.render(str(self.vidas), True, self.fondo)
        self.pantalla.blit(mensaje, (posX, posY))

class trianguloC:
    def __init__(self, x, y, lado, color, fondo, nombre, vidas, pantalla):
        self.x = x
        self.y = y
        self.vidas = vidas
        self.nombre = nombre
        self.fondo = fondo
        self.color = color
        self.lado = lado
        self.pantalla = pantalla
        self.left = Contorno(self.x,self.y,3,lado,"left",pantalla,color,fondo)
        self.up = Contorno(self.x, self.y, lado, 3, "up", pantalla, color, fondo)
        self.hip = DiagonalC(self.x+lado,self.y,self.lado,1.8,"hipC",pantalla,color,fondo)
        self.figura = [self.up, self.left, self.hip]

    def draw(self):
        self.up.borrar()
        self.left.borrar()
        self.hip.borrar()
        posX = self.x + 7
        posY = self.y + 7
        fuente = pygame.font.Font(None, 26)
        mensaje = fuente.render(str(self.vidas), True, self.color)
        self.pantalla.blit(mensaje, (posX, posY))

    def borrar(self):
        self.up.borrar()
        self.left.borrar()
        self.hip.borrar()
        posX = self.x + 7
        posY = self.y + 7
        fuente = pygame.font.Font(None, 26)
        mensaje = fuente.render(str(self.vidas), True, self.fondo)
        self.pantalla.blit(mensaje, (posX, posY))

class trianguloD:
    def __init__(self, x, y, lado, color, fondo, nombre, vidas, pantalla):
        self.x = x
        self.y = y
        self.vidas = vidas
        self.nombre = nombre
        self.fondo = fondo
        self.color = color
        self.lado = lado
        self.pantalla = pantalla
        self.right = Contorno(self.x+lado,self.y,-3,lado,"right",pantalla,color,fondo)
        self.down = Contorno(self.x, self.y + lado, lado, -3, "down", pantalla, color, fondo)
        self.hip = DiagonalD(self.x+ lado,self.y,self.lado,1.8,"hipD",pantalla,color,fondo)
        self.figura = [self.down, self.right, self.hip]

    def draw(self):
        self.down.draw()
        self.right.draw()
        self.hip.draw()
        posX = self.x + self.lado - 20
        posY = self.y + self.lado - 20
        fuente = pygame.font.Font(None, 26)
        mensaje = fuente.render(str(self.vidas), True, self.color)
        self.pantalla.blit(mensaje, (posX, posY))

    def borrar(self):
        self.down.borrar()
        self.right.borrar()
        self.hip.borrar()
        posX = self.x + self.lado - 20
        posY = self.y + self.lado - 20
        fuente = pygame.font.Font(None, 26)
        mensaje = fuente.render(str(self.vidas), True, self.fondo)
        self.pantalla.blit(mensaje, (posX, posY))