from centered_figure import *
import pygame
import math
from Fila import *
from contorno import *
import time

class Pelota:

    def __init__(self,vertices,centro,color,pantalla):
        self.ball = CenteredFigure(vertices,centro,color,0,pantalla)
        self.centro = centro
        self.color = color
        self.vertices = vertices
        self.pantalla = pantalla

    def draw(self):
        self.ball = CenteredFigure(self.vertices, self.centro, (255,255,255), 0, self.pantalla)
        self.ball.draw()

    def borrar(self):
        self.ball = CenteredFigure(self.vertices, self.centro, (0,0,0), 0, self.pantalla)
        self.ball.draw()

    def mover(self,angulo,lista1,lista2,lista3,ymax,r):
        angulo = angulo*pi/180
        self.borrar()
        self.centro[0] += r*cos(angulo)
        self.centro[1] += r*sin(angulo)
        self.draw()
        pygame.display.update()
        if self.centro[1] >= ymax:
            self.borrar()
            self.centro[1] = 549
            self.draw()
            return True

        for i in range(len(lista1)):
            lista1[i].draw()
            if self.ball.collide(lista1[i].figura):
                return [angulo*180/pi,i]

        for i in range(len(lista2)):
            #lista2[i].draw()
            if self.ball.collide(lista2[i].figura):
                return [angulo*180/pi,lista2[i],True]

        for i in range(len(lista3)):
            if self.ball.collide(lista3[i].figura):
                return [angulo*180/pi,lista3[i],True,True]
        return None


def moverHasta(bolas,angulo_inicial,contorno,filas,power,ymax):

    cuadros = cuadros_filas(filas)
    lista2 = elementos_filas(cuadros)

    comprobar = []
    obj = []
    obj1 = []
    lista22 = []
    lista11 = []
    angulos = []

    for bola in bolas:
        if bola.centro[1] != 550:
            comprobar += [False]
            obj += [[]]
            obj1 += [[]]
            lista22 += [lista2]
            lista11 += [contorno]
            angulos += [angulo_inicial]

    powers = 0
    cuadrosEliminados = []

    while True:

        while comprobar.count(False):

            for i in range(len(bolas)):
                if not comprobar[i]:

                    elementos = bolas[i].mover(angulos[i],lista11[i],lista22[i],power,ymax,4-(i*0.5))

                    lista11[i] += obj[i]
                    lista22[i] += obj1[i]

                    if elementos != None:
                        if elementos == True:
                            comprobar[i] = True
                            if comprobar.count(True) == 1:
                                pos = bolas[i].centro[0]
                            bolas[i].borrar()
                            bolas[i].centro[0] = pos
                            bolas[i].draw()

                        #Choques con los contornos
                        elif len(elementos) == 2:
                            obj1[i] = []
                            obj[i] = [lista11[i][elementos[1]]]
                            angulo = elementos[0]
                            beta = -abs(180 + angulos[i])

                            lista11[i].pop(elementos[1])
                            if obj[i][0].posicion == "left":
                                if abs(angulos[i]) <= 180: angulos[i] = beta
                                else: angulos[i] = -beta
                            elif obj[i][0].posicion == "right":
                                if abs(angulos[i]) <= 180: angulos[i] = beta
                                else: angulos[i] = -beta
                            elif obj[i][0].posicion == "up":
                                angulos[i] = -360-angulo
                            elif obj[i][0].posicion == "down":
                                break

                        # Choque con los bloques
                        elif len(elementos) == 3:
                            obj[i] = []
                            obj1[i] = [elementos[1]]

                            beta = -abs(180 + angulos[i])
                            angulo = elementos[0]

                            if obj1[i][0].posicion == "left":
                                if abs(angulos[i]) <= 180: angulos[i] = beta
                                else: angulos[i] = -beta
                            elif obj1[i][0].posicion == "right":
                                if abs(angulos[i]) <= 180: angulos[i] = beta
                                else: angulos[i] = -beta
                            elif obj1[i][0].posicion == "down":
                                angulos[i] = -360-angulo
                            elif obj1[i][0].posicion == "up":
                                angulos[i] = -180-beta

                            for cuadro in cuadros:
                                if obj1[i] != [] and cuadro.figura.count(obj1[i][0]):
                                    cuadro.borrar()
                                    cuadro.vidas -= 1

                                    if cuadro.vidas > 0:
                                        cuadro.draw()
                                        lista22[i].remove(elementos[1])
                                    else:
                                        cuadrosEliminados += [cuadro]
                                        lista22[i].remove(cuadro.up)
                                        lista22[i].remove(cuadro.down)
                                        lista22[i].remove(cuadro.left)
                                        lista22[i].remove(cuadro.right)
                                        cuadros.remove(cuadro)

                                        obj1[i] = []

                        elif len(elementos) == 4:
                            otrosPowers = [None]
                            if elementos[1].tipo == "+":
                                powers += 1
                                angulos[i] = elementos[0]
                                power.remove(elementos[1])
                                elementos[1].borrar()
                            elif elementos[1].tipo == "M":
                                angulos[i] = -random.randint(20,160)
                                if otrosPowers.count(elementos[1]) == 0:
                                    otrosPowers += [elementos[1]]

        return [powers,pos,cuadrosEliminados]