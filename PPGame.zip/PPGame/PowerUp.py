from centered_figure import *

VERDE = (89, 145, 0)
ROJO = (102, 51, 0)
AZUL = (0, 102, 255)
CELESTE = (51, 153, 255)

class powerUp:
    def __init__(self,tipo,centro,pantalla,nombre):
        self.tipo = tipo
        self.centro = centro
        self.pantalla = pantalla
        self.nombre = nombre
        self.figura = CenteredFigure([(6*cos(22.5*pi/180),6*sin(22.5*pi/180)),(6*cos(67.5*pi/180),6*sin(67.5*pi/180)),(-6*cos(67.5*pi/180),6*sin(67.5*pi/180)),(-6*cos(22.5*pi/180),6*sin(22.5*pi/180)),(-6*cos(22.5*pi/180),-6*sin(22.5*pi/180)),(-6*cos(67.5*pi/180),-6*sin(67.5*pi/180)),(6*cos(67.5*pi/180),-6*sin(67.5*pi/180)),(6*cos(22.5*pi/180),-6*sin(22.5*pi/180))],self.centro,(0,0,0),0,self.pantalla)

    def draw(self):
        if self.tipo == "+":
            figura = CenteredFigure([(6*cos(22.5*pi/180),6*sin(22.5*pi/180)),(6*cos(67.5*pi/180),6*sin(67.5*pi/180)),(-6*cos(67.5*pi/180),6*sin(67.5*pi/180)),(-6*cos(22.5*pi/180),6*sin(22.5*pi/180)),(-6*cos(22.5*pi/180),-6*sin(22.5*pi/180)),(-6*cos(67.5*pi/180),-6*sin(67.5*pi/180)),(6*cos(67.5*pi/180),-6*sin(67.5*pi/180)),(6*cos(22.5*pi/180),-6*sin(22.5*pi/180))],self.centro,VERDE,0,self.pantalla)
            figura.draw()
        elif self.tipo == "H":
            figura = CenteredFigure([(6*cos(22.5*pi/180),6*sin(22.5*pi/180)),(6*cos(67.5*pi/180),6*sin(67.5*pi/180)),(-6*cos(67.5*pi/180),6*sin(67.5*pi/180)),(-6*cos(22.5*pi/180),6*sin(22.5*pi/180)),(-6*cos(22.5*pi/180),-6*sin(22.5*pi/180)),(-6*cos(67.5*pi/180),-6*sin(67.5*pi/180)),(6*cos(67.5*pi/180),-6*sin(67.5*pi/180)),(6*cos(22.5*pi/180),-6*sin(22.5*pi/180))], self.centro, AZUL, 0, self.pantalla)
            figura.draw()
        elif self.tipo == "V":
            figura = CenteredFigure([(6*cos(22.5*pi/180),6*sin(22.5*pi/180)),(6*cos(67.5*pi/180),6*sin(67.5*pi/180)),(-6*cos(67.5*pi/180),6*sin(67.5*pi/180)),(-6*cos(22.5*pi/180),6*sin(22.5*pi/180)),(-6*cos(22.5*pi/180),-6*sin(22.5*pi/180)),(-6*cos(67.5*pi/180),-6*sin(67.5*pi/180)),(6*cos(67.5*pi/180),-6*sin(67.5*pi/180)),(6*cos(22.5*pi/180),-6*sin(22.5*pi/180))], self.centro, CELESTE, 0, self.pantalla)
            figura.draw()
        elif self.tipo == "M":
            figura = CenteredFigure([(6*cos(22.5*pi/180),6*sin(22.5*pi/180)),(6*cos(67.5*pi/180),6*sin(67.5*pi/180)),(-6*cos(67.5*pi/180),6*sin(67.5*pi/180)),(-6*cos(22.5*pi/180),6*sin(22.5*pi/180)),(-6*cos(22.5*pi/180),-6*sin(22.5*pi/180)),(-6*cos(67.5*pi/180),-6*sin(67.5*pi/180)),(6*cos(67.5*pi/180),-6*sin(67.5*pi/180)),(6*cos(22.5*pi/180),-6*sin(22.5*pi/180))], self.centro, ROJO, 0, self.pantalla)
            figura.draw()

    def borrar(self):
        self.figura.draw()
