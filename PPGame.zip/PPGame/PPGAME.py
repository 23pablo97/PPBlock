#Importamos librerias
import pygame
from Modelo import *
import sys
import time
from SelectBall import *
from Otros import *

pygame.init()
pantalla = pygame.display.set_mode((385,660))


comenzar = False
menu = False
estado = 0
vertices = [(6*cos(22.5*pi/180),6*sin(22.5*pi/180)),(6*cos(67.5*pi/180),6*sin(67.5*pi/180)),(-6*cos(67.5*pi/180),6*sin(67.5*pi/180)),(-6*cos(22.5*pi/180),6*sin(22.5*pi/180)),(-6*cos(22.5*pi/180),-6*sin(22.5*pi/180)),(-6*cos(67.5*pi/180),-6*sin(67.5*pi/180)),(6*cos(67.5*pi/180),-6*sin(67.5*pi/180)),(6*cos(22.5*pi/180),-6*sin(22.5*pi/180))]

while not comenzar:

    disenoMenu(pantalla,estado)
    fuente = pygame.font.Font("font/Pixeled.ttf", 15)

    pygame.display.update()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                sys.exit()



    if event.type == pygame.KEYDOWN:
        if event.key == pygame.K_UP:
            selector = fuente.render("o", True, NEGRO)
            pantalla.blit(selector, (18, 395 + 32 * estado))
            if estado != 0: estado-=1
            else: estado = 2


        if event.key == pygame.K_DOWN:
            selector = fuente.render("o", True, NEGRO)
            pantalla.blit(selector, (18, 395 + 32 * estado))
            if estado != 2: estado+=1
            else: estado = 0


    teclas = pygame.key.get_pressed()
    if teclas[pygame.K_SPACE]:
        if estado == 0:
            pantalla.fill((0, 0, 0))
            modelo(menu,vertices,pantalla)
            pantalla.fill((0, 0, 0))
        elif estado == 1:
            pantalla.fill((0, 0, 0))
            vertices = selectBall(pantalla)
            pantalla.fill((0, 0, 0))
        elif estado == 2:
            sys.exit()


    time.sleep(0.05)
