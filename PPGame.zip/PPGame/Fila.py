from Bloques import *
import random
from PowerUp import *
from BloqueTriangulo import *

BLANCO = (255,255,255)
NEGRO =(0,0,0)

def generarFila(celdas,lugar, nivel,pantalla):
    fila = []
    powerMas = False
    for i in range(celdas):
        objeto = random.choice([True,False])
        if objeto:
            if i == celdas-1 and not powerMas:
                power = powerUp("+", [i * 55 + 27, 55 + 27 + (lugar) * 55], pantalla, "POWER")
                fila += [power]
            else:
                if nivel % 10 == 0 and random.choice([nivel,2*nivel]) == 2*nivel:
                    cuadro = bloque(i * 55, 55 + (lugar) * 55, 53, (51, 102, 204), NEGRO, "CUADRADO", nivel, pantalla)
                else:
                    cuadro = bloque(i * 55, 55 + (lugar) * 55, 53, (0, 77, 0), NEGRO, "CUADRADO", nivel, pantalla)
                fila += [cuadro]
        else:
            objeto = random.choice([True, False])
            if objeto:
                if i == celdas-1 and not powerMas:
                    power = powerUp("+", [i * 55 + 27, 55 + 27 + (lugar) * 55], pantalla, "POWER")
                    fila += [power]
                else:
                    if not powerMas:
                        tipo = random.choice(["V","H","M","+","+","+"])
                        power = powerUp(tipo,[i*55+27,55+27+(lugar)*55],pantalla,"POWER")
                        if power.tipo == "+": powerMas = True
                    else:
                        tipo = random.choice(["V", "H", "M"])
                        power = powerUp(tipo, [i * 55 + 27, 55 + 27 + (lugar) * 55], pantalla, "POWER")
                    fila += [power]
            else:
                if i == celdas-1 and not powerMas:
                    power = powerUp("+", [i * 55 + 27, 55 + 27 + (lugar) * 55], pantalla, "POWER")
                    fila += [power]
                else: fila += [0]
    return fila

class fila:
    def __init__(self,celdas,lugar, nivel,pantalla):
        self.celdas = celdas
        self.lugar = lugar
        self.nivel = nivel
        self.lista = generarFila(self.celdas, self.lugar,self.nivel,pantalla)

    def pintarFila(self):
        for elemento in self.lista:
            if elemento != 0:
                if (elemento.nombre == "CUADRADO")and elemento.vidas > 0:
                    elemento.draw()
                elif elemento.nombre == "POWER":
                    elemento.draw()

    def borrarFila(self):
        for elemento in self.lista:
            if elemento != 0:
                elemento.borrar()

    def mover(self,aumentar):
        nuevaLista = []
        for i in self.lista:
            if i != 0:
                if i.nombre == "CUADRADO":
                    i.y += aumentar
                    i = bloque(i.x,i.y, i.lado,i.color,i.fondo,i.nombre,i.vidas,i.pantalla)
                    nuevaLista += [i]
                elif i.nombre == "POWER":
                    i.centro[1] += aumentar
                    i = powerUp(i.tipo,i.centro,i.pantalla,"POWER")
                    nuevaLista += [i]
            else: nuevaLista += [0]
        self.lista = nuevaLista

    def moverAbajo(self):
        self.borrarFila()
        self.mover(55)
        self.pintarFila()
        self.lugar += 1

    def cuadros(self):
        lista = []
        for i in self.lista:
            if i != 0 and i.nombre == "CUADRADO":
                lista += [i]
        return lista



    def eliminarElemento(self, elemento):
        self.lista.remove(elemento)

def moverFilas(filas,pantalla,nivel):
    for i in range(1,len(filas)):
        filas[-i] = filas[-i - 1]
    filas[0] = fila(7,0,nivel,pantalla)
    for i in range(1, len(filas) + 1):
        if filas[-i] != 0:
            #Movemos la fila en la pantalla
            filas[-i].moverAbajo()
    return filas

def cuadros_filas(filas):
    cuadros = []
    for i in filas:
        if i != 0:
            cuadros += i.cuadros()
    return cuadros

def power_filas(filas):
    powers = []
    for i in filas:
        if i != 0:
            for elemento in i.lista:
                if elemento != 0 and elemento.nombre == "POWER":
                    powers += [elemento]
    return powers







def elementos_filas(cuadros):
    elementos = []
    for i in cuadros:
        elementos += i.figura
    return elementos

def actualizar(fila):
    for i in range(len(fila)):
        if fila[i] != 0:
            for j in range(len(fila[i].lista)):
                if fila[i].lista[j] != 0 and fila[i].lista[j].nombre == "CUADRADO" and fila[i].lista[j].vidas <= 0:
                    fila[i].lista[j] = 0
    return fila

