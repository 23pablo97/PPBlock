from centered_figure import *

class Contorno:

    def __init__(self, x,y, ancho,alto,posicion,pantalla,color,fondo):
        self.x = x
        self.y = y
        self.ancho = ancho
        self.alto = alto
        self.posicion = posicion
        self.color=color
        self.fondo=fondo
        self.pantalla = pantalla
        self.figura = self.figura = CenteredFigure([(0, 0),(self.ancho,abs(self.ancho)),(self.ancho,self.alto-abs(self.ancho)),(0,self.alto)], [self.x, self.y], self.color, 0, self.pantalla)

    def draw(self):
        if self.posicion == "right" or self.posicion == "left":
            self.figura = CenteredFigure([(0, 0),(self.ancho,abs(self.ancho)),(self.ancho,self.alto-abs(self.ancho)),(0,self.alto)], [self.x, self.y], self.color, 0, self.pantalla)
        elif self.posicion == "up" or self.posicion == "down":
            self.figura = CenteredFigure([(0, 0),(self.ancho,0),(self.ancho-abs(self.alto),self.alto),(abs(self.alto),self.alto)], [self.x, self.y], self.color, 0, self.pantalla)
        self.figura.draw()

    def borrar(self):
        if self.posicion == "right" or self.posicion == "left":
            self.figura = CenteredFigure([(0, 0),(self.ancho,self.ancho),(self.ancho,self.alto-self.ancho),(0,self.alto)], [self.x, self.y], self.fondo, 0, self.pantalla)
        elif self.posicion == "up" or self.posicion == "down":
            self.figura = CenteredFigure([(0, 0),(self.ancho,0),(self.ancho-self.alto,self.alto),(self.alto,self.alto)], [self.x, self.y], self.fondo, 0, self.pantalla)
        self.figura.draw()








